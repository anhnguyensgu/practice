const container = document.querySelector("#container");
const availableItemsList = document.querySelector('#output');
const yourItems = document.querySelector('#your-items');


function createItem(id) {
    const newElement = document.createElement('div');
    newElement.setAttribute('id', 'moving-div-' + id);
    const randomNumber = Math.floor((Math.random() * 10) + 1) % 2;
    const move = randomNumber % 2 === 0 ? 'horizontal-move' : 'vertical-move';
    newElement.setAttribute('class', `movable ${move}`);
    container.appendChild(newElement);
    newElement.addEventListener('click', function (e) {
        pickingItem(e.target.id.replace('moving-div-', ''));
    })
}

function removeItem(id) {
    for (let i = 0; i < container.childElementCount; i++) {
        if (container.children[i].id === 'moving-div-' + id) {
            container.removeChild(container.children[i]);
            return;
        }
    }
}

function printAvailableItems(items) {
    availableItemsList.innerHTML = '';
    items.forEach(item => {
        const newItemTag = document.createElement('li');
        newItemTag.appendChild(document.createTextNode(item.name))
        availableItemsList.appendChild(newItemTag)
    });
}

async function pickingItem(id) {
    const data = await fetch('http://localhost:8080/picking/' + id);
    const responseBody = await data.json();
    console.log(responseBody);
    removeItem(id);
    const {pickedSuccess, name} = responseBody;
    if (pickedSuccess) {
        const newItemTag = document.createElement('li');
        newItemTag.appendChild(document.createTextNode(name));
        yourItems.appendChild(newItemTag);
    }
}

async function initializeItemList() {
    try {
        const data = await fetch('http://localhost:8080/items');
        const items = await data.json();
        items.forEach(item => createItem(item.id));
        printAvailableItems(items)
    } catch (e) {
        console.error(e);
    }

}

async function initWS() {
    const url = 'ws://localhost:8080/ws';
    const c = new WebSocket(url);
    c.onmessage = printItemStatistics
}

function printItemStatistics(body) {
    const {data} = body;
    const remainingItems = JSON.parse(data);
    for (let i = 0; i < container.childElementCount; i++) {
        const removedItem = remainingItems.find(item => {
            const currElementId = parseInt(container.children[i].id.replace('moving-div-', ''));
            return item.id === currElementId;
        });
        if (!removedItem) {
            container.removeChild(container.children[i]);
        }
    }
    printAvailableItems(remainingItems)
    // document.querySelector("#output").append(body.data + "\n");
}

initializeItemList();
initWS();